package com.example.hw8_32194677

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val login_btn = findViewById<Button>(R.id.login_btn)
        var input_username = findViewById<EditText>(R.id.input_id)
        var input_password = findViewById<EditText>(R.id.input_pw)

        val sharedPref = getSharedPreferences("kr.ac.dankook.example.SHARED_PREF", Context.MODE_PRIVATE);
        val editor = sharedPref.edit()

        val username:String? = sharedPref.getString("username", "")
        val password:String? = sharedPref.getString("password", "")
        val id = sharedPref.getInt("id", -1)

        editor.clear().commit()
        if(id==-1) {
            Log.d("DKU", "wait user input(username&password) & click “Login” button")
            System.out.println("wait user input(username&password) & click “Login” button")
        }
        else {
            val username:String? = sharedPref.getString("username", "")
            val password:String? = sharedPref.getString("password", "")
            input_username.setText(username)
            input_password.setText((password))
            Log.d("DKU", "read stored SharedPreferences (username, password & id), and it can be override with “Login” button")
            System.out.println("read stored SharedPreferences (username, password & id), and it can be override with “Login” button")
        }

        login_btn.setOnClickListener {

                editor.putString("username", input_username.text.toString())
                editor.putString("password", input_password.text.toString())
                editor.putInt("id", 1)
                editor.apply()
                Log.d("DKU", "save username & password to SharedPreferences (set id=1)")
                System.out.println("save username & password to SharedPreferences (set id=1)")

        }






    }
}