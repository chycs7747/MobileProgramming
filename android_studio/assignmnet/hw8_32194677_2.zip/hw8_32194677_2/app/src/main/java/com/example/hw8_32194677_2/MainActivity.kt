package com.example.hw8_32194677_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.Button
import androidx.room.Room

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = Room.databaseBuilder(
            applicationContext,
            UserDB::class.java, "userdb" )
            .allowMainThreadQueries().build()


        // you can clear all elements in database by using this code
        //db.userDao().deleteAll(db.userDao().getAll())

        val login_btn = findViewById<Button>(R.id.login_btn)
        var input_username = findViewById<EditText>(R.id.input_id)
        var input_password = findViewById<EditText>(R.id.input_pw)
        var userLogList = db.userDao().getAll();

        if(userLogList.isEmpty()) {2
            Log.d("DKU", "wait user input(username&password) & click “Login” button")
            System.out.println("wait user input(username&password) & click “Login” button")
        }
        else {
            input_username.setText(userLogList[userLogList.size-1].username)
            input_password.setText(userLogList[userLogList.size-1].password)

            Log.d("DKU", "read stored SharedPreferences (username, password & id), and it can be override with “Login” button")
        }

        /*
        When you clicked login btn, then id will be increased.
        */
        login_btn.setOnClickListener {
            userLogList = db.userDao().getAll();
            Log.d("DKU", (userLogList.size+1).toString())
            val user = User(userLogList.size + 1, input_username.text.toString(), input_password.text.toString());
            db.userDao().insertAll(user)
            Log.d("DKU", "save username & password to SharedPreferences (set id=${userLogList.size + 1})")
            System.out.println("save username & password to SharedPreferences (set id=${userLogList.size + 1})")
        }
    }


}