package com.example.hw8_32194677_2

import androidx.room.*

@Entity(tableName="users")
data class User(
    @PrimaryKey val uid: Int,
    @ColumnInfo(name = "username_log") val username: String?,
    @ColumnInfo(name = "password_log") val password: String?
)


@Dao
interface UserDao {
    @Query("SELECT * FROM users")
    fun getAll(): List<User>
    @Query("SELECT * FROM users WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray): List<User>
    @Query("SELECT * FROM users WHERE username_log LIKE :first AND " +
            "password_log LIKE :last LIMIT 1")
    fun findByName(first: String, last: String): User
    @Insert
    fun insertAll(vararg users: User)
    @Delete
    fun delete(users: List<User>)
}

@Database(entities = arrayOf(User::class), version=1)
abstract class UserDB : RoomDatabase() {
    abstract fun userDao(): UserDao
}

