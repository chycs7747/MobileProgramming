package com.example.hw9_32194677_2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout. activity_main)
        val buttonStart = findViewById<Button>(R.id.startBtn)
        val buttonStop = findViewById<Button>(R.id.stopBtn)
        val helloText = findViewById<TextView>(R.id.helloText)
        var totalSecond = 0;
        var isRunning : Boolean = true

        val myHandler = object : Handler(Looper.getMainLooper()) {
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)
                Log.d("BkgThread", "Main thread")
                if(msg.what == 1) {
                    val minute = String.format("%02d", msg.arg1 / 60)
                    val second = String.format("%02d", msg.arg1 % 60)
                    helloText.setText("${minute}:${second}")
                }
            }
        }

        buttonStart.setOnClickListener {
            Thread {
                isRunning = true
                while(isRunning == true) {
                    totalSecond += 1
                    var msg = myHandler.obtainMessage()
                    msg.what = 1
                    msg.arg1 = totalSecond
                    myHandler.sendMessage(msg)
                    Thread.sleep(1000)
                }
            }.start()
        }
        buttonStop.setOnClickListener {
            totalSecond = 0
            isRunning = false
        }
    }
}